package com.collectx.backend.controller;

import com.collectx.backend.dto.request.UpdateRoleRequest;
import com.collectx.backend.dto.request.UpdateStatusRequest;
import com.collectx.backend.dto.response.ApiResponse;
import com.collectx.backend.dto.response.UserResponse;
import com.collectx.backend.repository.AuditLogRepository;
import com.collectx.backend.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
@Tag(name = "Admin", description = "User management endpoints — ADMIN role required")
@SecurityRequirement(name = "bearerAuth")
public class AdminController {

    private final UserService        userService;
    private final AuditLogRepository auditLogRepository;

    @Operation(summary = "Get all users")
    @GetMapping("/users")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllUsers() {
        return ResponseEntity.ok(ApiResponse.ok("Users fetched", userService.getAllUsers()));
    }

    @Operation(summary = "Get user by ID")
    @GetMapping("/users/{id}")
    public ResponseEntity<ApiResponse<UserResponse>> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("User fetched", userService.getUserById(id)));
    }

    @Operation(summary = "Get users by role", description = "e.g. /admin/users/role/AGENT")
    @GetMapping("/users/role/{role}")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getUsersByRole(@PathVariable String role) {
        return ResponseEntity.ok(ApiResponse.ok("Users fetched", userService.getUsersByRole(role)));
    }

    @Operation(summary = "Update user role", description = "Body: { \"role\": \"MANAGER\" }")
    @PutMapping("/users/{id}/role")
    public ResponseEntity<ApiResponse<UserResponse>> updateRole(
            @PathVariable Long id,
            @Valid @RequestBody UpdateRoleRequest request) {

        UserResponse updated = userService.updateRole(id, request.getRole());
        return ResponseEntity.ok(ApiResponse.ok("Role updated to " + request.getRole(), updated));
    }

    @Operation(summary = "Update user status", description = "Body: { \"status\": \"INACTIVE\" }")
    @PutMapping("/users/{id}/status")
    public ResponseEntity<ApiResponse<UserResponse>> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody UpdateStatusRequest request) {

        UserResponse updated = userService.updateStatus(id, request.getStatus());
        return ResponseEntity.ok(ApiResponse.ok("Status updated to " + request.getStatus(), updated));
    }

    @Operation(summary = "Delete user permanently")
    @DeleteMapping("/users/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(ApiResponse.ok("User deleted successfully"));
    }

    @Operation(summary = "Get all audit logs")
    @GetMapping("/audit-logs")
    public ResponseEntity<ApiResponse<List<?>>> getAllAuditLogs() {
        return ResponseEntity.ok(
                ApiResponse.ok("Audit logs fetched",
                        auditLogRepository.findAllByOrderByTimestampDesc()));
    }

    @Operation(summary = "Get audit logs for a specific user")
    @GetMapping("/users/{id}/audit-logs")
    public ResponseEntity<ApiResponse<List<?>>> getUserAuditLogs(@PathVariable Long id) {
        return ResponseEntity.ok(
                ApiResponse.ok("Audit logs fetched",
                        userService.getAuditLogsForUser(id)));
    }
}
