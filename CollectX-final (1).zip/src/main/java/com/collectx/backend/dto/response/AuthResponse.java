package com.collectx.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {

    private String token;
    private String refreshToken;

    @Builder.Default
    private String tokenType = "Bearer";

    private String email;
    private String role;
    private Long userId;
}
