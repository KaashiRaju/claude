package com.collectx.backend.service;

import com.collectx.backend.dto.response.UserResponse;
import com.collectx.backend.entity.User;
import com.collectx.backend.enums.Role;
import com.collectx.backend.enums.UserStatus;
import com.collectx.backend.exception.ResourceNotFoundException;
import com.collectx.backend.repository.AuditLogRepository;
import com.collectx.backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository     userRepository;
    private final AuditLogRepository auditLogRepository;

    // ── Get all users ─────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map(UserResponse::from)
                .collect(Collectors.toList());
    }

    // ── Get user by ID ────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public UserResponse getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return UserResponse.from(user);
    }

    // ── Get users by role ─────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<UserResponse> getUsersByRole(String roleName) {
        Role role;
        try {
            role = Role.valueOf(roleName.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid role: " + roleName);
        }
        return userRepository.findByRole(role)
                .stream()
                .map(UserResponse::from)
                .collect(Collectors.toList());
    }

    // ── Update role ───────────────────────────────────────────────────────────

    @Transactional
    public UserResponse updateRole(Long id, String roleName) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

        Role newRole;
        try {
            newRole = Role.valueOf(roleName.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid role. Allowed: ADMIN, MANAGER, AGENT");
        }

        user.setRole(newRole);
        userRepository.save(user);
        log.info("Role updated for user {} → {}", user.getEmail(), newRole);
        return UserResponse.from(user);
    }

    // ── Update status ─────────────────────────────────────────────────────────

    @Transactional
    public UserResponse updateStatus(Long id, String statusName) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

        UserStatus newStatus;
        try {
            newStatus = UserStatus.valueOf(statusName.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid status. Allowed: ACTIVE, INACTIVE");
        }

        user.setStatus(newStatus);
        userRepository.save(user);
        log.info("Status updated for user {} → {}", user.getEmail(), newStatus);
        return UserResponse.from(user);
    }

    // ── Delete user ───────────────────────────────────────────────────────────

    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

        // Remove audit logs first (FK constraint)
        auditLogRepository.deleteAll(auditLogRepository.findByUserOrderByTimestampDesc(user));
        userRepository.delete(user);
        log.info("User deleted: {}", user.getEmail());
    }

    // ── Get audit logs for a user ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<?> getAuditLogsForUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return auditLogRepository.findByUserOrderByTimestampDesc(user);
    }
}
