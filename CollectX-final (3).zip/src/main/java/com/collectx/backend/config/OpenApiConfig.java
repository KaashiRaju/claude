package com.collectx.backend.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(
        info = @Info(
                title       = "CollectX Backend API",
                version     = "1.0.0",
                description = "REST API for CollectX — Authentication, RBAC, User Management",
                contact     = @Contact(name = "CollectX Team")
        ),
        servers = @Server(url = "http://localhost:5000", description = "Local development server")
)
@SecurityScheme(
        name        = "bearerAuth",
        type        = SecuritySchemeType.HTTP,
        scheme      = "bearer",
        bearerFormat = "JWT",
        in          = SecuritySchemeIn.HEADER,
        description = "Paste your JWT token here (without 'Bearer' prefix)"
)
public class OpenApiConfig {
    // All config done via annotations above
}
