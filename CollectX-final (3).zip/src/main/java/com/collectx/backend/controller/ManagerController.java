package com.collectx.backend.controller;

import com.collectx.backend.dto.response.ApiResponse;
import com.collectx.backend.dto.response.UserResponse;
import com.collectx.backend.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/manager")
@PreAuthorize("hasAnyRole('MANAGER', 'ADMIN')")
@Tag(name = "Manager", description = "Team management - MANAGER or ADMIN role required")
@SecurityRequirement(name = "bearerAuth")
public class ManagerController {

    private final UserService userService;

    public ManagerController(UserService userService) { this.userService = userService; }

    @Operation(summary = "Manager dashboard")
    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<String>> dashboard(Authentication authentication) {
        return ResponseEntity.ok(ApiResponse.ok("Welcome Manager: " + authentication.getName()
                + " | Authorities: " + authentication.getAuthorities()));
    }

    @Operation(summary = "Get all agents")
    @GetMapping("/agents")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAgents() {
        return ResponseEntity.ok(ApiResponse.ok("Agents fetched", userService.getUsersByRole("AGENT")));
    }
}
