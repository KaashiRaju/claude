package com.collectx.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ResetPasswordRequest {
    @NotBlank(message = "Token is required")
    private String token;

    @NotBlank(message = "New password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String newPassword;

    public String getToken()          { return token; }
    public String getNewPassword()    { return newPassword; }
    public void setToken(String v)       { this.token = v; }
    public void setNewPassword(String v) { this.newPassword = v; }
}
