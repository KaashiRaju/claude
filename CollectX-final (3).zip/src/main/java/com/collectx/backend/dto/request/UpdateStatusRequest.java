package com.collectx.backend.dto.request;

import jakarta.validation.constraints.NotBlank;

public class UpdateStatusRequest {
    @NotBlank(message = "Status is required")
    private String status;

    public String getStatus()       { return status; }
    public void setStatus(String v) { this.status = v; }
}
