package com.collectx.backend.dto.response;

public class AuthResponse {
    private String token;
    private String refreshToken;
    private String tokenType = "Bearer";
    private String email;
    private String role;
    private Long userId;

    public AuthResponse() {}
    public AuthResponse(String token, String refreshToken, String tokenType, String email, String role, Long userId) {
        this.token = token; this.refreshToken = refreshToken; this.tokenType = tokenType;
        this.email = email; this.role = role; this.userId = userId;
    }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private String token, refreshToken, tokenType = "Bearer", email, role; private Long userId;
        public Builder token(String v)        { this.token = v; return this; }
        public Builder refreshToken(String v) { this.refreshToken = v; return this; }
        public Builder tokenType(String v)    { this.tokenType = v; return this; }
        public Builder email(String v)        { this.email = v; return this; }
        public Builder role(String v)         { this.role = v; return this; }
        public Builder userId(Long v)         { this.userId = v; return this; }
        public AuthResponse build() { return new AuthResponse(token, refreshToken, tokenType, email, role, userId); }
    }

    public String getToken()        { return token; }
    public String getRefreshToken() { return refreshToken; }
    public String getTokenType()    { return tokenType; }
    public String getEmail()        { return email; }
    public String getRole()         { return role; }
    public Long getUserId()         { return userId; }
}
