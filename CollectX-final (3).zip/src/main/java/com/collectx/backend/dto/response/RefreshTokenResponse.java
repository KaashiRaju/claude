package com.collectx.backend.dto.response;

public class RefreshTokenResponse {
    private String accessToken;
    private String refreshToken;
    private String tokenType = "Bearer";

    public RefreshTokenResponse() {}
    public RefreshTokenResponse(String accessToken, String refreshToken, String tokenType) {
        this.accessToken = accessToken; this.refreshToken = refreshToken; this.tokenType = tokenType;
    }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private String accessToken, refreshToken, tokenType = "Bearer";
        public Builder accessToken(String v)  { this.accessToken = v; return this; }
        public Builder refreshToken(String v) { this.refreshToken = v; return this; }
        public Builder tokenType(String v)    { this.tokenType = v; return this; }
        public RefreshTokenResponse build() { return new RefreshTokenResponse(accessToken, refreshToken, tokenType); }
    }

    public String getAccessToken()  { return accessToken; }
    public String getRefreshToken() { return refreshToken; }
    public String getTokenType()    { return tokenType; }
}
