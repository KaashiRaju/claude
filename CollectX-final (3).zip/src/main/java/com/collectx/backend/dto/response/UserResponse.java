package com.collectx.backend.dto.response;

import com.collectx.backend.entity.User;
import com.collectx.backend.enums.Role;
import com.collectx.backend.enums.UserStatus;

public class UserResponse {
    private Long userId;
    private String name;
    private String email;
    private Role role;
    private UserStatus status;

    public UserResponse() {}
    public UserResponse(Long userId, String name, String email, Role role, UserStatus status) {
        this.userId = userId; this.name = name; this.email = email; this.role = role; this.status = status;
    }

    public static UserResponse from(User user) {
        return new UserResponse(user.getUserId(), user.getName(), user.getEmail(), user.getRole(), user.getStatus());
    }

    public Long getUserId()      { return userId; }
    public String getName()      { return name; }
    public String getEmail()     { return email; }
    public Role getRole()        { return role; }
    public UserStatus getStatus(){ return status; }
}
