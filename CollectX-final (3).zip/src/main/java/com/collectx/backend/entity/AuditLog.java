package com.collectx.backend.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_log")
public class AuditLog {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long auditId;

    @Column(nullable = false) private String action;
    @Column(nullable = false) private String resource;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime timestamp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public AuditLog() {}
    public AuditLog(Long auditId, String action, String resource, LocalDateTime timestamp, User user) {
        this.auditId = auditId; this.action = action; this.resource = resource;
        this.timestamp = timestamp; this.user = user;
    }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long auditId; private String action; private String resource;
        private LocalDateTime timestamp; private User user;
        public Builder auditId(Long v)        { this.auditId = v; return this; }
        public Builder action(String v)       { this.action = v; return this; }
        public Builder resource(String v)     { this.resource = v; return this; }
        public Builder timestamp(LocalDateTime v){ this.timestamp = v; return this; }
        public Builder user(User v)           { this.user = v; return this; }
        public AuditLog build() { return new AuditLog(auditId, action, resource, timestamp, user); }
    }

    public Long getAuditId()         { return auditId; }
    public String getAction()        { return action; }
    public String getResource()      { return resource; }
    public LocalDateTime getTimestamp(){ return timestamp; }
    public User getUser()            { return user; }
    public void setAction(String v)  { this.action = v; }
    public void setResource(String v){ this.resource = v; }
    public void setUser(User v)      { this.user = v; }
}
