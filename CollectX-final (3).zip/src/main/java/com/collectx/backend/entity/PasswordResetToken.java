package com.collectx.backend.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "password_reset_token")
public class PasswordResetToken {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true) private String token;
    @Column(nullable = false) private LocalDateTime expiryTime;
    private boolean used;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public PasswordResetToken() {}
    public PasswordResetToken(Long id, String token, LocalDateTime expiryTime, boolean used, User user) {
        this.id = id; this.token = token; this.expiryTime = expiryTime; this.used = used; this.user = user;
    }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long id; private String token; private LocalDateTime expiryTime; private boolean used; private User user;
        public Builder id(Long v)              { this.id = v; return this; }
        public Builder token(String v)         { this.token = v; return this; }
        public Builder expiryTime(LocalDateTime v){ this.expiryTime = v; return this; }
        public Builder used(boolean v)         { this.used = v; return this; }
        public Builder user(User v)            { this.user = v; return this; }
        public PasswordResetToken build() { return new PasswordResetToken(id, token, expiryTime, used, user); }
    }

    public Long getId()                  { return id; }
    public String getToken()             { return token; }
    public LocalDateTime getExpiryTime() { return expiryTime; }
    public boolean isUsed()              { return used; }
    public User getUser()                { return user; }
    public void setUsed(boolean v)       { this.used = v; }
    public boolean isExpired() { return LocalDateTime.now().isAfter(expiryTime); }
}
