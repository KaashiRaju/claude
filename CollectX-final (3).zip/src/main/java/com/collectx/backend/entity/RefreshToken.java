package com.collectx.backend.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "refresh_token")
public class RefreshToken {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 512) private String token;
    @Column(nullable = false) private LocalDateTime expiryTime;
    @CreationTimestamp private LocalDateTime createdAt;
    private boolean revoked;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public RefreshToken() {}
    public RefreshToken(Long id, String token, LocalDateTime expiryTime, LocalDateTime createdAt, boolean revoked, User user) {
        this.id = id; this.token = token; this.expiryTime = expiryTime;
        this.createdAt = createdAt; this.revoked = revoked; this.user = user;
    }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long id; private String token; private LocalDateTime expiryTime;
        private LocalDateTime createdAt; private boolean revoked; private User user;
        public Builder id(Long v)              { this.id = v; return this; }
        public Builder token(String v)         { this.token = v; return this; }
        public Builder expiryTime(LocalDateTime v){ this.expiryTime = v; return this; }
        public Builder createdAt(LocalDateTime v){ this.createdAt = v; return this; }
        public Builder revoked(boolean v)      { this.revoked = v; return this; }
        public Builder user(User v)            { this.user = v; return this; }
        public RefreshToken build() { return new RefreshToken(id, token, expiryTime, createdAt, revoked, user); }
    }

    public Long getId()                  { return id; }
    public String getToken()             { return token; }
    public LocalDateTime getExpiryTime() { return expiryTime; }
    public LocalDateTime getCreatedAt()  { return createdAt; }
    public boolean isRevoked()           { return revoked; }
    public User getUser()                { return user; }
    public void setRevoked(boolean v)    { this.revoked = v; }
    public boolean isExpired() { return LocalDateTime.now().isAfter(expiryTime); }
}
