package com.collectx.backend.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "user_session")
public class Session {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sessionId;

    @Column(nullable = false, length = 512) private String token;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime loginTime;

    private LocalDateTime logoutTime;
    private String ipAddress;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public Session() {}
    public Session(Long sessionId, String token, LocalDateTime loginTime, LocalDateTime logoutTime, String ipAddress, User user) {
        this.sessionId = sessionId; this.token = token; this.loginTime = loginTime;
        this.logoutTime = logoutTime; this.ipAddress = ipAddress; this.user = user;
    }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private Long sessionId; private String token; private LocalDateTime loginTime;
        private LocalDateTime logoutTime; private String ipAddress; private User user;
        public Builder sessionId(Long v)        { this.sessionId = v; return this; }
        public Builder token(String v)          { this.token = v; return this; }
        public Builder loginTime(LocalDateTime v){ this.loginTime = v; return this; }
        public Builder logoutTime(LocalDateTime v){ this.logoutTime = v; return this; }
        public Builder ipAddress(String v)      { this.ipAddress = v; return this; }
        public Builder user(User v)             { this.user = v; return this; }
        public Session build() { return new Session(sessionId, token, loginTime, logoutTime, ipAddress, user); }
    }

    public Long getSessionId()           { return sessionId; }
    public String getToken()             { return token; }
    public LocalDateTime getLoginTime()  { return loginTime; }
    public LocalDateTime getLogoutTime() { return logoutTime; }
    public String getIpAddress()         { return ipAddress; }
    public User getUser()                { return user; }
    public void setToken(String v)       { this.token = v; }
    public void setLogoutTime(LocalDateTime v){ this.logoutTime = v; }
    public void setIpAddress(String v)   { this.ipAddress = v; }
    public void setUser(User v)          { this.user = v; }
}
