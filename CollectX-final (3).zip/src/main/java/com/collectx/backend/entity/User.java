package com.collectx.backend.entity;

import com.collectx.backend.enums.Role;
import com.collectx.backend.enums.UserStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "user_info", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @JsonIgnore
    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserStatus status;

    public User() {}

    public User(Long userId, String name, String email, String password, Role role, UserStatus status) {
        this.userId = userId; this.name = name; this.email = email;
        this.password = password; this.role = role; this.status = status;
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long userId; private String name; private String email;
        private String password; private Role role; private UserStatus status;
        public Builder userId(Long v)      { this.userId = v; return this; }
        public Builder name(String v)      { this.name = v; return this; }
        public Builder email(String v)     { this.email = v; return this; }
        public Builder password(String v)  { this.password = v; return this; }
        public Builder role(Role v)        { this.role = v; return this; }
        public Builder status(UserStatus v){ this.status = v; return this; }
        public User build() { return new User(userId, name, email, password, role, status); }
    }

    public Long getUserId()      { return userId; }
    public String getName()      { return name; }
    public String getEmail()     { return email; }
    public String getPassword()  { return password; }
    public Role getRole()        { return role; }
    public UserStatus getStatus(){ return status; }

    public void setUserId(Long v)      { this.userId = v; }
    public void setName(String v)      { this.name = v; }
    public void setEmail(String v)     { this.email = v; }
    public void setPassword(String v)  { this.password = v; }
    public void setRole(Role v)        { this.role = v; }
    public void setStatus(UserStatus v){ this.status = v; }
}
