package com.collectx.backend.enums;

public enum Role {
    ADMIN,
    MANAGER,
    AGENT
}
