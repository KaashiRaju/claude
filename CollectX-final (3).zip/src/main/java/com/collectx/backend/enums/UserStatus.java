package com.collectx.backend.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE
}
