package com.collectx.backend.repository;

import com.collectx.backend.entity.AuditLog;
import com.collectx.backend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findByUserOrderByTimestampDesc(User user);

    List<AuditLog> findAllByOrderByTimestampDesc();
}
