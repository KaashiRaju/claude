package com.collectx.backend.service;

import com.collectx.backend.dto.request.LoginRequest;
import com.collectx.backend.dto.request.SignupRequest;
import com.collectx.backend.dto.response.AuthResponse;
import com.collectx.backend.dto.response.RefreshTokenResponse;
import com.collectx.backend.entity.*;
import com.collectx.backend.enums.Role;
import com.collectx.backend.enums.UserStatus;
import com.collectx.backend.exception.ResourceNotFoundException;
import com.collectx.backend.repository.*;
import com.collectx.backend.util.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final SessionRepository sessionRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;
    private final RefreshTokenService refreshTokenService;
    private final EmailService emailService;

    public AuthService(UserRepository userRepository, AuditLogRepository auditLogRepository,
                       SessionRepository sessionRepository, JwtUtil jwtUtil,
                       PasswordEncoder passwordEncoder, RefreshTokenService refreshTokenService,
                       EmailService emailService) {
        this.userRepository = userRepository; this.auditLogRepository = auditLogRepository;
        this.sessionRepository = sessionRepository; this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder; this.refreshTokenService = refreshTokenService;
        this.emailService = emailService;
    }

    @Transactional
    public String signup(SignupRequest request) {
        if (userRepository.existsByEmail(request.getEmail()))
            throw new IllegalArgumentException("Email is already registered");

        Role assignedRole;
        try {
            assignedRole = (request.getRole() != null && !request.getRole().isBlank())
                    ? Role.valueOf(request.getRole().toUpperCase()) : Role.AGENT;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid role. Allowed: ADMIN, MANAGER, AGENT");
        }

        User user = User.builder().name(request.getName())
                .email(request.getEmail().toLowerCase())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(assignedRole).status(UserStatus.ACTIVE).build();
        userRepository.save(user);
        log.info("New user registered: {} with role: {}", user.getEmail(), assignedRole);
        auditLog("SIGNUP", "AUTH", user);
        try { emailService.sendWelcomeEmail(user.getEmail(), user.getName()); }
        catch (Exception ignored) { log.warn("Welcome email failed for {}", user.getEmail()); }
        return "User registered successfully with role: " + assignedRole;
    }

    @Transactional
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail().toLowerCase())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        if (user.getStatus() == UserStatus.INACTIVE)
            throw new IllegalArgumentException("Account is deactivated. Contact your administrator.");
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword()))
            throw new IllegalArgumentException("Invalid password");

        String accessToken = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getUserId());
        RefreshToken refresh = refreshTokenService.createRefreshToken(user);

        Session session = Session.builder().token(accessToken).user(user).build();
        sessionRepository.save(session);
        log.info("User logged in: {}", user.getEmail());
        auditLog("LOGIN", "AUTH", user);

        return AuthResponse.builder().token(accessToken).refreshToken(refresh.getToken())
                .tokenType("Bearer").email(user.getEmail())
                .role(user.getRole().name()).userId(user.getUserId()).build();
    }

    @Transactional
    public RefreshTokenResponse refreshToken(String refreshToken) {
        RefreshToken rt = refreshTokenService.validateRefreshToken(refreshToken);
        User user = rt.getUser();
        String newAccessToken = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getUserId());
        RefreshToken newRefresh = refreshTokenService.createRefreshToken(user);
        return RefreshTokenResponse.builder().accessToken(newAccessToken).refreshToken(newRefresh.getToken()).build();
    }

    @Transactional
    public String logout(String token) {
        String email = jwtUtil.extractEmail(token);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        sessionRepository.findByToken(token).ifPresent(session -> {
            session.setLogoutTime(LocalDateTime.now());
            sessionRepository.save(session);
        });
        refreshTokenService.revokeRefreshToken(token);
        log.info("User logged out: {}", email);
        auditLog("LOGOUT", "AUTH", user);
        return "Logged out successfully";
    }

    private void auditLog(String action, String resource, User user) {
        auditLogRepository.save(AuditLog.builder().action(action).resource(resource).user(user).build());
    }
}
