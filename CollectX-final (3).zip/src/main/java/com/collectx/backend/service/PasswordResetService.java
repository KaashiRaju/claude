package com.collectx.backend.service;

import com.collectx.backend.entity.PasswordResetToken;
import com.collectx.backend.entity.User;
import com.collectx.backend.exception.ResourceNotFoundException;
import com.collectx.backend.repository.PasswordResetTokenRepository;
import com.collectx.backend.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class PasswordResetService {

    private static final Logger log = LoggerFactory.getLogger(PasswordResetService.class);

    private final UserRepository userRepository;
    private final PasswordResetTokenRepository tokenRepository;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.password-reset.expiry-minutes}")
    private int expiryMinutes;

    public PasswordResetService(UserRepository userRepository, PasswordResetTokenRepository tokenRepository,
                                EmailService emailService, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository; this.tokenRepository = tokenRepository;
        this.emailService = emailService; this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public String forgotPassword(String email) {
        User user = userRepository.findByEmail(email.toLowerCase())
                .orElseThrow(() -> new ResourceNotFoundException("No account found with this email"));
        tokenRepository.deleteAllByUser(user);
        String token = UUID.randomUUID().toString();
        PasswordResetToken resetToken = PasswordResetToken.builder()
                .token(token).user(user)
                .expiryTime(LocalDateTime.now().plusMinutes(expiryMinutes))
                .used(false).build();
        tokenRepository.save(resetToken);
        emailService.sendPasswordResetEmail(user.getEmail(), token);
        log.info("Password reset token generated for {}", email);
        return "Password reset email sent to " + email;
    }

    @Transactional
    public String resetPassword(String token, String newPassword) {
        PasswordResetToken resetToken = tokenRepository.findByToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Invalid or expired reset token"));
        if (resetToken.isUsed()) throw new IllegalArgumentException("This reset token has already been used");
        if (resetToken.isExpired()) {
            tokenRepository.delete(resetToken);
            throw new IllegalArgumentException("Reset token has expired. Please request a new one.");
        }
        User user = resetToken.getUser();
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
        resetToken.setUsed(true);
        tokenRepository.save(resetToken);
        log.info("Password reset successfully for {}", user.getEmail());
        return "Password reset successfully. You can now login with your new password.";
    }
}
