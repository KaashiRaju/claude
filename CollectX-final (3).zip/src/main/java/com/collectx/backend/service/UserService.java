package com.collectx.backend.service;

import com.collectx.backend.dto.response.UserResponse;
import com.collectx.backend.entity.User;
import com.collectx.backend.enums.Role;
import com.collectx.backend.enums.UserStatus;
import com.collectx.backend.exception.ResourceNotFoundException;
import com.collectx.backend.repository.AuditLogRepository;
import com.collectx.backend.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);

    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;

    public UserService(UserRepository userRepository, AuditLogRepository auditLogRepository) {
        this.userRepository = userRepository; this.auditLogRepository = auditLogRepository;
    }

    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(UserResponse::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public UserResponse getUserById(Long id) {
        return UserResponse.from(userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id)));
    }

    @Transactional(readOnly = true)
    public List<UserResponse> getUsersByRole(String roleName) {
        Role role;
        try { role = Role.valueOf(roleName.toUpperCase()); }
        catch (IllegalArgumentException e) { throw new IllegalArgumentException("Invalid role: " + roleName); }
        return userRepository.findByRole(role).stream().map(UserResponse::from).collect(Collectors.toList());
    }

    @Transactional
    public UserResponse updateRole(Long id, String roleName) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        Role newRole;
        try { newRole = Role.valueOf(roleName.toUpperCase()); }
        catch (IllegalArgumentException e) { throw new IllegalArgumentException("Invalid role. Allowed: ADMIN, MANAGER, AGENT"); }
        user.setRole(newRole);
        userRepository.save(user);
        log.info("Role updated for user {}", user.getEmail());
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse updateStatus(Long id, String statusName) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        UserStatus newStatus;
        try { newStatus = UserStatus.valueOf(statusName.toUpperCase()); }
        catch (IllegalArgumentException e) { throw new IllegalArgumentException("Invalid status. Allowed: ACTIVE, INACTIVE"); }
        user.setStatus(newStatus);
        userRepository.save(user);
        log.info("Status updated for user {}", user.getEmail());
        return UserResponse.from(user);
    }

    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        auditLogRepository.deleteAll(auditLogRepository.findByUserOrderByTimestampDesc(user));
        userRepository.delete(user);
        log.info("User deleted: {}", user.getEmail());
    }

    @Transactional(readOnly = true)
    public List<?> getAuditLogsForUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return auditLogRepository.findByUserOrderByTimestampDesc(user);
    }
}
