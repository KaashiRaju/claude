package com.collectx.backend.util;

import com.collectx.backend.enums.Role;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class JwtUtil {

    private final SecretKey key;
    private final long expirationMs;

    public JwtUtil(
            @Value("${jwt.secret}") String secret,
            @Value("${jwt.expiration-ms}") long expirationMs) {
        this.key = Keys.hmacShaKeyFor(secret.getBytes());
        this.expirationMs = expirationMs;
    }

    // ── Generate ─────────────────────────────────────────────────────────────

    public String generateToken(String email, Role role, Long userId) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("role",   role.name());
        claims.put("userId", userId);

        return Jwts.builder()
                .claims(claims)                                              // 0.12.x API
                .subject(email)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(key)
                .compact();
    }

    // ── Extract ──────────────────────────────────────────────────────────────

    public String extractEmail(String token) {
        return parseClaims(token).getSubject();
    }

    public String extractRole(String token) {
        return (String) parseClaims(token).get("role");
    }

    public Long extractUserId(String token) {
        Object id = parseClaims(token).get("userId");
        if (id instanceof Integer) return ((Integer) id).longValue();
        return (Long) id;
    }

    // ── Validate ─────────────────────────────────────────────────────────────

    public boolean isTokenValid(String token) {
        try {
            parseClaims(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }

    // ── Private ──────────────────────────────────────────────────────────────

    private Claims parseClaims(String token) {
        return Jwts.parser()                       // 0.12.x — replaces parserBuilder()
                .verifyWith(key)                   // 0.12.x — replaces setSigningKey()
                .build()
                .parseSignedClaims(token)          // 0.12.x — replaces parseClaimsJws()
                .getPayload();                     // 0.12.x — replaces getBody()
    }
}
