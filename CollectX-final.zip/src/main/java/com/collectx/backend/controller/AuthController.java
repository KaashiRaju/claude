package com.collectx.backend.controller;

import com.collectx.backend.dto.request.LoginRequest;
import com.collectx.backend.dto.request.SignupRequest;
import com.collectx.backend.dto.response.ApiResponse;
import com.collectx.backend.dto.response.AuthResponse;
import com.collectx.backend.dto.response.UserResponse;
import com.collectx.backend.security.CustomUserDetails;
import com.collectx.backend.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Signup, login, logout and profile endpoints")
public class AuthController {

    private final AuthService authService;

    @Operation(summary = "Register a new user", description = "Public — defaults to role AGENT if no role provided")
    @PostMapping("/signup")
    public ResponseEntity<ApiResponse<String>> signup(
            @Valid @RequestBody SignupRequest request) {

        String message = authService.signup(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.ok(message));
    }

    @Operation(summary = "Login and receive JWT token", description = "Public — returns Bearer token on success")
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request) {

        AuthResponse response = authService.login(request);
        return ResponseEntity.ok(ApiResponse.ok("Login successful", response));
    }

    @Operation(summary = "Logout current session", description = "Requires Bearer token")
    @SecurityRequirement(name = "bearerAuth")
    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<String>> logout(
            @RequestHeader("Authorization") String authHeader) {

        String token = authHeader.replace("Bearer ", "").trim();
        String message = authService.logout(token);
        return ResponseEntity.ok(ApiResponse.ok(message));
    }

    @Operation(summary = "Get current user profile", description = "Requires Bearer token")
    @SecurityRequirement(name = "bearerAuth")
    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserResponse>> me(
            @AuthenticationPrincipal CustomUserDetails userDetails) {

        UserResponse response = UserResponse.from(userDetails.getUser());
        return ResponseEntity.ok(ApiResponse.ok("Profile fetched", response));
    }
}
