package com.collectx.backend.service;

import com.collectx.backend.dto.request.LoginRequest;
import com.collectx.backend.dto.request.SignupRequest;
import com.collectx.backend.dto.response.AuthResponse;
import com.collectx.backend.entity.AuditLog;
import com.collectx.backend.entity.Session;
import com.collectx.backend.entity.User;
import com.collectx.backend.enums.Role;
import com.collectx.backend.enums.UserStatus;
import com.collectx.backend.exception.ResourceNotFoundException;
import com.collectx.backend.repository.AuditLogRepository;
import com.collectx.backend.repository.SessionRepository;
import com.collectx.backend.repository.UserRepository;
import com.collectx.backend.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository      userRepository;
    private final AuditLogRepository  auditLogRepository;
    private final SessionRepository   sessionRepository;
    private final JwtUtil             jwtUtil;
    private final PasswordEncoder     passwordEncoder;

    // ── Signup ────────────────────────────────────────────────────────────────

    @Transactional
    public String signup(SignupRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Email is already registered");
        }

        Role assignedRole;
        try {
            assignedRole = (request.getRole() != null && !request.getRole().isBlank())
                    ? Role.valueOf(request.getRole().toUpperCase())
                    : Role.AGENT;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid role. Allowed: ADMIN, MANAGER, AGENT");
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail().toLowerCase())
                .password(passwordEncoder.encode(request.getPassword()))  // BCrypt hash
                .role(assignedRole)
                .status(UserStatus.ACTIVE)
                .build();

        userRepository.save(user);
        log.info("New user registered: {} with role: {}", user.getEmail(), assignedRole);

        auditLog("SIGNUP", "AUTH", user);
        return "User registered successfully with role: " + assignedRole;
    }

    // ── Login ─────────────────────────────────────────────────────────────────

    @Transactional
    public AuthResponse login(LoginRequest request) {

        User user = userRepository.findByEmail(request.getEmail().toLowerCase())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (user.getStatus() == UserStatus.INACTIVE) {
            throw new IllegalArgumentException("Account is deactivated. Contact your administrator.");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new IllegalArgumentException("Invalid password");
        }

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getUserId());

        // Persist session
        Session session = Session.builder()
                .token(token)
                .user(user)
                .build();
        sessionRepository.save(session);

        log.info("User logged in: {}", user.getEmail());
        auditLog("LOGIN", "AUTH", user);

        return AuthResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .email(user.getEmail())
                .role(user.getRole().name())
                .userId(user.getUserId())
                .build();
    }

    // ── Logout ────────────────────────────────────────────────────────────────

    @Transactional
    public String logout(String token) {

        String email = jwtUtil.extractEmail(token);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // Mark session logout time
        sessionRepository.findByToken(token).ifPresent(session -> {
            session.setLogoutTime(LocalDateTime.now());
            sessionRepository.save(session);
        });

        log.info("User logged out: {}", email);
        auditLog("LOGOUT", "AUTH", user);
        return "Logged out successfully";
    }

    // ── Private helper ────────────────────────────────────────────────────────

    private void auditLog(String action, String resource, User user) {
        AuditLog log = AuditLog.builder()
                .action(action)
                .resource(resource)
                .user(user)
                .build();
        auditLogRepository.save(log);
    }
}
